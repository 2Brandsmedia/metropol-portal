<?php
/**
 * Debug-Datei für Metropol Portal
 * Nach erfolgreicher Installation löschen!
 */

echo "<h1>Debug Mode</h1>";
echo "BASE_PATH: " . __DIR__ . "<br><br>";

try {
    // 1. Libraries laden
    echo "<h2>1. Lade Libraries...</h2>";
    
    $files = ['Autoloader', 'Env', 'Database', 'Router', 'Session'];
    foreach ($files as $file) {
        $path = __DIR__ . '/lib/' . $file . '.php';
        if (file_exists($path)) {
            require_once $path;
            echo "✅ $file geladen<br>";
        } else {
            echo "❌ $file nicht gefunden!<br>";
        }
    }
    
    // 2. Environment laden
    echo "<h2>2. Lade Environment...</h2>";
    Env::load(__DIR__);
    echo "✅ Environment geladen<br>";
    echo "APP_DEBUG: " . (Env::get('APP_DEBUG', 'nicht gesetzt')) . "<br>";
    
    // 3. Test .env file
    echo "<h2>3. Test .env Datei...</h2>";
    $envPath = __DIR__ . '/.env';
    if (file_exists($envPath)) {
        echo "✅ .env gefunden<br>";
        echo "Dateigröße: " . filesize($envPath) . " bytes<br>";
        echo "Ist lesbar: " . (is_readable($envPath) ? "Ja" : "Nein") . "<br>";
        echo "Ist Datei: " . (is_file($envPath) ? "Ja" : "Nein") . "<br>";
        
        // Zeige erste Zeilen (ohne sensible Daten)
        $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        echo "<br>Erste Zeilen (ohne Werte):<br>";
        foreach (array_slice($lines, 0, 5) as $line) {
            if (strpos($line, '=') !== false) {
                list($key, ) = explode('=', $line, 2);
                echo "$key=***<br>";
            }
        }
    } else {
        echo "❌ .env nicht gefunden!<br>";
    }
    
    // 4. Session test
    echo "<h2>4. Starte Session...</h2>";
    Session::configure(['lifetime' => 7200]);
    Session::start();
    echo "✅ Session gestartet<br>";
    
    // 5. Application laden
    echo "<h2>5. Lade Application...</h2>";
    require_once __DIR__ . '/src/Core/Application.php';
    if (class_exists('\\App\\Core\\Application')) {
        echo "✅ Application-Klasse gefunden<br>";
        try {
            $app = \App\Core\Application::getInstance();
            echo "✅ Application instanziiert<br>";
        } catch (Exception $e) {
            echo "❌ Application-Fehler: " . $e->getMessage() . "<br>";
            echo "Stack:<br><pre>" . $e->getTraceAsString() . "</pre>";
        }
    } else {
        echo "❌ Application-Klasse nicht gefunden!<br>";
    }
    
} catch (Exception $e) {
    echo "<h2>Kritischer Fehler:</h2>";
    echo "<pre>" . $e->getMessage() . "</pre>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

echo "<hr>";
echo "<small>Diese Datei nach erfolgreicher Fehlerbehebung löschen!</small>";