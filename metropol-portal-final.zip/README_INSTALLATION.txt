===========================================================
METROPOL PORTAL - INSTALLATIONS-ANLEITUNG
===========================================================

WICHTIG: Bitte genau befolgen für eine erfolgreiche Installation!

===========================================================
SCHRITT 1: DATEIEN HOCHLADEN
===========================================================

1. Laden Sie diese ZIP-Datei per FTP hoch
2. WICHTIG: Entpacken Sie direkt im Hauptverzeichnis!
   
   RICHTIG: /public_html/ oder /htdocs/ oder /www/
   FALSCH:  /public_html/irgendein-ordner/

3. Nach dem Entpacken sollte die Struktur so aussehen:
   /ihre-domain.de/
   ├── install.php
   ├── test.php
   ├── public/
   ├── lib/
   └── ... weitere Ordner

===========================================================
SCHRITT 2: TESTEN
===========================================================

1. Öffnen Sie: http://ihre-domain.de/test.php
2. Alle Punkte sollten grün (✅) sein
3. Falls etwas rot (❌) ist, beheben Sie es zuerst

===========================================================
SCHRITT 3: INSTALLATION
===========================================================

1. Öffnen Sie: http://ihre-domain.de/install.php
2. Folgen Sie den 6 Schritten:
   - Sprache wählen
   - System-Check (sollte alles grün sein)
   - Datenbank-Daten eingeben
   - Admin-Account erstellen
   - Basis-Einstellungen
   - Installation abschließen

===========================================================
SCHRITT 4: PORTAL NUTZEN
===========================================================

Nach erfolgreicher Installation:

1. Portal-Zugang: http://ihre-domain.de/public/
2. Mit Ihrem Admin-Account einloggen
3. Fertig!

===========================================================
FEHLERBEHEBUNG
===========================================================

PROBLEM: "Zu viele Weiterleitungen"
LÖSUNG: Alle .htaccess Dateien löschen

PROBLEM: "Seite nicht gefunden"
LÖSUNG: Prüfen Sie ob alle Dateien richtig entpackt wurden

PROBLEM: "Datenbankfehler"
LÖSUNG: Prüfen Sie die Zugangsdaten beim Hoster

===========================================================
SUPPORT
===========================================================

Bei Problemen:
1. Führen Sie test.php aus
2. Notieren Sie alle Fehlermeldungen
3. Kontakt: support@2brands-media.de

Viel Erfolg!
2Brands Media GmbH