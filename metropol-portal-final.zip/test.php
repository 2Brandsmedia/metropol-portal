<?php
/**
 * Metropol Portal - Test & Debug Datei
 * 
 * Diese Datei hilft bei der Fehlersuche
 * Löschen Sie diese nach erfolgreicher Installation!
 */

echo "<h1>Metropol Portal - System Check</h1>";
echo "<hr>";

// PHP Version
echo "<h2>1. PHP Version:</h2>";
echo "<p>Ihre Version: <strong>" . PHP_VERSION . "</strong></p>";
$phpOk = version_compare(PHP_VERSION, '8.1.0', '>=');
echo $phpOk ? "✅ PHP 8.1+ gefunden" : "❌ PHP zu alt! Mindestens 8.1 erforderlich";

// Wichtige Extensions
echo "<h2>2. PHP Extensions:</h2>";
$required = ['pdo', 'pdo_mysql', 'json', 'mbstring', 'curl', 'session'];
echo "<ul>";
foreach ($required as $ext) {
    $loaded = extension_loaded($ext);
    echo "<li>" . $ext . ": " . ($loaded ? "✅ OK" : "❌ FEHLT!") . "</li>";
}
echo "</ul>";

// Verzeichnisstruktur
echo "<h2>3. Verzeichnisstruktur:</h2>";
echo "<p>Aktuelles Verzeichnis: <code>" . __DIR__ . "</code></p>";
echo "<p>Gefundene Verzeichnisse:</p>";
echo "<ul>";
$dirs = ['public', 'lib', 'src', 'installer', 'templates', 'database', 'lang'];
foreach ($dirs as $dir) {
    $exists = is_dir(__DIR__ . '/' . $dir);
    echo "<li>/{$dir}/ " . ($exists ? "✅ Vorhanden" : "❌ Fehlt") . "</li>";
}
echo "</ul>";

// Wichtige Dateien
echo "<h2>4. Wichtige Dateien:</h2>";
echo "<ul>";
$files = [
    'install.php' => 'Installer',
    'public/index.php' => 'Hauptdatei',
    'lib/Autoloader.php' => 'Autoloader',
    '.env' => 'Konfiguration (nach Installation)'
];
foreach ($files as $file => $desc) {
    $exists = file_exists(__DIR__ . '/' . $file);
    echo "<li>{$file} ({$desc}): " . ($exists ? "✅ OK" : "⚠️ Noch nicht vorhanden") . "</li>";
}
echo "</ul>";

// Installation Status
echo "<h2>5. Installation:</h2>";
if (file_exists(__DIR__ . '/.env')) {
    echo "✅ Portal ist installiert<br>";
    echo '<a href="public/" style="background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">→ Zum Portal</a>';
} else {
    echo "⚠️ Portal ist noch nicht installiert<br>";
    echo '<a href="install.php" style="background: #2196F3; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">→ Jetzt installieren</a>';
}

echo "<hr>";
echo "<p><small>Diese Datei können Sie nach erfolgreicher Installation löschen.</small></p>";